# Razorpay integration setup

The existing bookstore checkout now supports Razorpay in addition to COD, direct UPI, and bank deposit.

## Environment variables

Set these in the deployment environment (for example Vercel Project Settings → Environment Variables). Never commit real values to GitHub.

- `RAZORPAY_KEY_ID` — Razorpay Test/Live Key ID (`rzp_test_...` or `rzp_live_...`)
- `RAZORPAY_KEY_SECRET` — Razorpay Key Secret
- `RAZORPAY_WEBHOOK_SECRET` — a webhook secret you choose in the Razorpay dashboard

Use Test Mode credentials first.

## Razorpay Dashboard webhook

Configure:

`https://YOUR-DOMAIN/api/payments/webhook`

Subscribe to at least:

- `payment.captured`
- `payment.failed`
- `refund.processed`

The webhook signature is verified against the raw request body.

## Payment flow

1. `CheckoutPage.tsx` sends only cart IDs/quantities and customer details.
2. `POST /api/payments/create-order` recalculates prices, discounts, GST and shipping from the server-side catalog.
3. The server creates the Razorpay order and stores a pending local order.
4. Razorpay Checkout opens in the browser using only the public Key ID.
5. `POST /api/payments/verify` verifies the HMAC signature and fetches the Razorpay payment to confirm captured amount/currency.
6. Stock is reduced only after verified capture.
7. The webhook independently reconciles captured/failed/refunded events and is idempotent by event ID.

## Important deployment limitation

The current application stores its database in `db.json`. In Vercel the existing code uses `/tmp/db.json`, which is not durable storage across serverless invocations. Razorpay should not be considered production-safe until order/payment persistence is moved to a durable database (or an existing durable datastore is wired into `server.ts`).

## Do not commit secrets

`.env*` is ignored by `.gitignore` except `.env.example`. Put real Razorpay credentials only in the hosting provider's secret/environment-variable settings.
